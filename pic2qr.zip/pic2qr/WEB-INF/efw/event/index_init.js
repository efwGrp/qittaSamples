var index_init={};
index_init.paramsFormat={};
index_init.fire=function(params){
	var downloadurl=properties.get("pic2qr.download.url");
	var ary=new Record(file.list(""))
		.map({
			"name":"name",
			encodedUrl:function(data){
				return encodeURIComponent(downloadurl+"?pic="+data.name);
			}
		}).getArray();
	return (new Result())
	.runat("body")
	.remove("div")
	.append("<div style='width:400px;display:inline-block;text-align:center'>"
		+"<img src='drawServlet?type=qrcode&msg={encodedUrl}' style='width:300px;'>"
		+"<br><span>{name}</span></div>")
	.withdata(ary);
}