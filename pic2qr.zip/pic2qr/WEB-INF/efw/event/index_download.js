var index_download={};
index_download.paramsFormat={pic:null};
index_download.fire=function(params){
	var pic=params.pic;
	return new Result()
	.attach(pic);
}